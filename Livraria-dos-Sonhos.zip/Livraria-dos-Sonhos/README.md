# Livraria dos Sonhos

Biblioteca virtual com identidade visual rosa bebê, flores animadas, cadastro/login, painel administrativo, catálogo de PDFs, fórum e avaliações.

## Funcionalidades
- Cadastro e login com senhas armazenadas por hash.
- Painel administrativo com lista de usuários, data de cadastro e último login.
- Cadastro de livros, sinopses e upload opcional de PDF (até 20 MB).
- Fórum de leitores.
- Avaliações de 1 a 5 estrelas; cada usuário pode avaliar cada livro uma vez.
- Layout responsivo e animação de pétalas que respeita a preferência por movimento reduzido.

## Requisitos
Python 3.10 ou superior.

## Executar no Windows com VS Code
1. Instale o Python e o VS Code.
2. Baixe o repositório pelo botão **Code > Download ZIP** no GitHub e extraia a pasta, ou clone o repositório.
3. Abra a pasta no VS Code: **File > Open Folder**.
4. Abra **Terminal > New Terminal**.
5. Crie um ambiente virtual:
   ```powershell
   py -m venv .venv
   ```
6. Ative o ambiente:
   ```powershell
   .\.venv\Scripts\Activate.ps1
   ```
   Se o PowerShell bloquear a ativação, abra um terminal CMD e execute `.venv\Scripts\activate.bat`.
7. Instale as dependências:
   ```powershell
   python -m pip install -r requirements.txt
   ```
8. Configure o e-mail administrador no terminal PowerShell **antes de iniciar**:
   ```powershell
   $env:ADMIN_EMAIL="seu-email-real@exemplo.com"
   $env:SECRET_KEY="substitua-por-uma-chave-aleatoria-longa"
   ```
   Escolha seu e-mail real para `ADMIN_EMAIL`. Cadastre-se na aplicação usando exatamente esse e-mail. Se a conta já existir, entre novamente para que o papel administrativo seja atualizado.
9. Inicie o site:
   ```powershell
   python app.py
   ```
10. Abra `http://127.0.0.1:5000` no navegador. Para parar o servidor, pressione `Ctrl+C` no terminal.

As variáveis definidas no terminal valem apenas para aquela sessão. Defina-as novamente quando abrir outro terminal.

## Pastas
- `templates/`: páginas HTML.
- `static/css/style.css`: identidade visual e animações.
- `data/`: banco SQLite criado automaticamente na primeira execução.
- `uploads/`: PDFs enviados pelo administrador.

O banco local e os PDFs são ignorados pelo Git. Faça backup deles separadamente; não os coloque no repositório público.

## Segurança antes de publicar
Este é um projeto inicial para estudo e execução local. Antes de expor o site na internet, implemente proteção CSRF, limitação de tentativas de login, validação mais forte de uploads e uma política de moderação do fórum. Use `SECRET_KEY` forte, HTTPS, armazenamento persistente e servidor WSGI de produção. Não use o servidor de desenvolvimento do Flask em produção. Publique apenas PDFs que você tenha autorização para distribuir.
