import os
import sqlite3
from pathlib import Path
from functools import wraps
from datetime import datetime
from flask import Flask, request, redirect, url_for, session, flash, render_template, send_from_directory, abort
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = Path(os.environ.get("LIVRARIA_DATA_DIR", BASE_DIR / "data"))
UPLOAD_DIR = Path(os.environ.get("LIVRARIA_UPLOAD_DIR", BASE_DIR / "uploads"))
DATA_DIR.mkdir(parents=True, exist_ok=True)
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = DATA_DIR / "livraria.sqlite3"

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "chave-local-temporaria-troque-antes-de-publicar")
app.config["MAX_CONTENT_LENGTH"] = 20 * 1024 * 1024
ADMIN_EMAIL = os.environ.get("ADMIN_EMAIL", "").strip().lower()
ALLOWED_EXTENSIONS = {"pdf"}


def connect_db():
    db = sqlite3.connect(DB_PATH)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA foreign_keys = ON")
    return db


def init_db():
    with connect_db() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'user',
            created_at TEXT NOT NULL,
            last_login TEXT
        );
        CREATE TABLE IF NOT EXISTS books (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            author TEXT NOT NULL,
            description TEXT NOT NULL,
            filename TEXT,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS posts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            title TEXT NOT NULL,
            body TEXT NOT NULL,
            created_at TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS reviews (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            book_id INTEGER NOT NULL,
            rating INTEGER NOT NULL CHECK(rating BETWEEN 1 AND 5),
            comment TEXT NOT NULL,
            created_at TEXT NOT NULL,
            UNIQUE(user_id, book_id),
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY(book_id) REFERENCES books(id) ON DELETE CASCADE
        );
        """)
        if ADMIN_EMAIL:
            db.execute("UPDATE users SET role='admin' WHERE lower(email)=?", (ADMIN_EMAIL,))


def now():
    return datetime.now().strftime("%d/%m/%Y %H:%M")


def get_user():
    user_id = session.get("user_id")
    if not user_id:
        return None
    with connect_db() as db:
        return db.execute(
            "SELECT id, name, email, role, created_at, last_login FROM users WHERE id=?",
            (user_id,)
        ).fetchone()


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not get_user():
            flash("Entre na sua conta para acessar esta área.")
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped


def admin_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        user = get_user()
        if not user or user["role"] != "admin":
            abort(403)
        return view(*args, **kwargs)
    return wrapped


def allowed_pdf(file):
    return bool(file and file.filename and Path(file.filename).suffix.lower() == ".pdf")


@app.after_request
def security_headers(response):
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "SAMEORIGIN")
    response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    return response


@app.route("/")
def home():
    with connect_db() as db:
        books = db.execute("""
            SELECT b.id, b.title, b.author, b.description, b.filename,
                   COALESCE(ROUND(AVG(r.rating), 1), 0) AS average,
                   COUNT(r.id) AS review_count
            FROM books b LEFT JOIN reviews r ON r.book_id = b.id
            GROUP BY b.id ORDER BY b.id DESC
        """).fetchall()
    return render_template("home.html", title="Início", books=books, user=get_user())


@app.route("/cadastro", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        if not name or len(name) > 80 or not email or len(password) < 8:
            flash("Preencha os campos. A senha deve ter pelo menos 8 caracteres.")
            return render_template("register.html", title="Cadastro", user=get_user())
        role = "admin" if ADMIN_EMAIL and email == ADMIN_EMAIL else "user"
        try:
            with connect_db() as db:
                db.execute(
                    "INSERT INTO users(name,email,password_hash,role,created_at) VALUES(?,?,?,?,?)",
                    (name, email, generate_password_hash(password), role, now())
                )
            flash("Cadastro concluído! Agora você pode entrar.")
            return redirect(url_for("login"))
        except sqlite3.IntegrityError:
            flash("Já existe uma conta com esse e-mail.")
    return render_template("register.html", title="Cadastro", user=get_user())


@app.route("/entrar", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        with connect_db() as db:
            account = db.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
            if account and ADMIN_EMAIL and email == ADMIN_EMAIL and account["role"] != "admin":
                db.execute("UPDATE users SET role='admin' WHERE id=?", (account["id"],))
                account = db.execute("SELECT * FROM users WHERE id=?", (account["id"],)).fetchone()
            if account and check_password_hash(account["password_hash"], password):
                session.clear()
                session["user_id"] = account["id"]
                db.execute("UPDATE users SET last_login=? WHERE id=?", (now(), account["id"]))
                flash("Login realizado com sucesso.")
                return redirect(url_for("home"))
        flash("E-mail ou senha incorretos.")
    return render_template("login.html", title="Entrar", user=get_user())


@app.route("/sair")
def logout():
    session.clear()
    flash("Você saiu da sua conta.")
    return redirect(url_for("home"))


@app.route("/forum", methods=["GET", "POST"])
def forum():
    user = get_user()
    if request.method == "POST":
        if not user:
            return redirect(url_for("login"))
        title = request.form.get("title", "").strip()
        body = request.form.get("body", "").strip()
        if not title or not body or len(title) > 120 or len(body) > 3000:
            flash("Informe um título e uma mensagem (limite de 120 e 3.000 caracteres).")
        else:
            with connect_db() as db:
                db.execute(
                    "INSERT INTO posts(user_id,title,body,created_at) VALUES(?,?,?,?)",
                    (user["id"], title, body, now())
                )
            flash("Seu tópico foi publicado.")
            return redirect(url_for("forum"))
    with connect_db() as db:
        posts = db.execute("""
            SELECT p.id,p.title,p.body,p.created_at,u.name
            FROM posts p JOIN users u ON u.id=p.user_id ORDER BY p.id DESC
        """).fetchall()
    return render_template("forum.html", title="Fórum", user=user, posts=posts)


@app.route("/avaliacoes", methods=["GET", "POST"])
def reviews():
    user = get_user()
    if request.method == "POST":
        if not user:
            return redirect(url_for("login"))
        try:
            book_id = int(request.form.get("book_id", "0"))
            rating = int(request.form.get("rating", "0"))
        except ValueError:
            abort(400)
        comment = request.form.get("comment", "").strip()
        if rating not in range(1, 6) or not comment or len(comment) > 2000:
            flash("Escolha uma nota de 1 a 5 e escreva um comentário de até 2.000 caracteres.")
        else:
            try:
                with connect_db() as db:
                    db.execute(
                        "INSERT INTO reviews(user_id,book_id,rating,comment,created_at) VALUES(?,?,?,?,?)",
                        (user["id"], book_id, rating, comment, now())
                    )
                flash("Sua avaliação foi publicada.")
                return redirect(url_for("reviews"))
            except sqlite3.IntegrityError:
                flash("Você já avaliou este livro ou o livro não existe.")
    with connect_db() as db:
        books = db.execute("SELECT id,title,author FROM books ORDER BY title").fetchall()
        reviews_list = db.execute("""
            SELECT r.rating,r.comment,r.created_at,u.name,b.title
            FROM reviews r JOIN users u ON u.id=r.user_id
            JOIN books b ON b.id=r.book_id ORDER BY r.id DESC
        """).fetchall()
    return render_template("reviews.html", title="Avaliações", user=user,
                           books=books, reviews=reviews_list)


@app.route("/admin")
@login_required
@admin_required
def admin():
    with connect_db() as db:
        users = db.execute(
            "SELECT name,email,role,created_at,last_login FROM users ORDER BY id DESC"
        ).fetchall()
        books = db.execute("SELECT * FROM books ORDER BY id DESC").fetchall()
        post_count = db.execute("SELECT COUNT(*) AS n FROM posts").fetchone()["n"]
        review_count = db.execute("SELECT COUNT(*) AS n FROM reviews").fetchone()["n"]
    return render_template("admin.html", title="Administração", user=get_user(),
                           users=users, books=books, post_count=post_count,
                           review_count=review_count)


@app.route("/admin/livros/adicionar", methods=["POST"])
@login_required
@admin_required
def add_book():
    title = request.form.get("title", "").strip()
    author = request.form.get("author", "").strip()
    description = request.form.get("description", "").strip()
    upload = request.files.get("pdf")
    if not title or not author or not description or len(title) > 180 or len(author) > 120 or len(description) > 3000:
        flash("Confira título, autor e sinopse. Respeite os limites dos campos.")
        return redirect(url_for("admin"))
    filename = None
    if upload and upload.filename:
        if not allowed_pdf(upload):
            flash("Envie somente arquivos com extensão .pdf.")
            return redirect(url_for("admin"))
        safe_name = secure_filename(upload.filename)
        filename = f"{datetime.now().strftime('%Y%m%d%H%M%S%f')}_{safe_name}"
        upload.save(UPLOAD_DIR / filename)
    with connect_db() as db:
        db.execute(
            "INSERT INTO books(title,author,description,filename,created_at) VALUES(?,?,?,?,?)",
            (title, author, description, filename, now())
        )
    flash("Livro adicionado ao catálogo.")
    return redirect(url_for("admin"))


@app.route("/admin/livros/<int:book_id>/excluir", methods=["POST"])
@login_required
@admin_required
def delete_book(book_id):
    with connect_db() as db:
        book = db.execute("SELECT filename FROM books WHERE id=?", (book_id,)).fetchone()
        if not book:
            abort(404)
        db.execute("DELETE FROM books WHERE id=?", (book_id,))
    if book["filename"]:
        try:
            (UPLOAD_DIR / book["filename"]).unlink(missing_ok=True)
        except OSError:
            app.logger.exception("Não foi possível apagar o PDF do livro %s", book_id)
    flash("Livro removido do catálogo.")
    return redirect(url_for("admin"))


@app.route("/pdf/<int:book_id>")
@login_required
def download_pdf(book_id):
    with connect_db() as db:
        book = db.execute("SELECT filename FROM books WHERE id=?", (book_id,)).fetchone()
    if not book or not book["filename"]:
        abort(404)
    return send_from_directory(UPLOAD_DIR, book["filename"], as_attachment=False)


@app.errorhandler(403)
def forbidden(_error):
    return render_template("error.html", title="Acesso restrito", user=get_user(),
                           message="Esta página é exclusiva da administração."), 403


@app.errorhandler(404)
def not_found(_error):
    return render_template("error.html", title="Página não encontrada", user=get_user(),
                           message="Não encontramos o conteúdo solicitado."), 404


@app.errorhandler(413)
def too_large(_error):
    flash("O arquivo é maior que o limite de 20 MB.")
    return redirect(url_for("admin"))


init_db()

if __name__ == "__main__":
    # Apenas para desenvolvimento local. Em produção, use um servidor WSGI.
    app.run(debug=os.environ.get("FLASK_DEBUG") == "1")
