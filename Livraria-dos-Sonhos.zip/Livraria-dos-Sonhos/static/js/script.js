(() => {
  const toggle = document.querySelector(".menu-toggle");
  const links = document.querySelector(".nav-links");
  if (toggle && links) {
    toggle.addEventListener("click", () => {
      const open = links.classList.toggle("open");
      toggle.setAttribute("aria-expanded", String(open));
    });
  }

  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  if (reduceMotion) return;

  const petals = ["✿", "❀", "✽"];
  function createPetal() {
    const petal = document.createElement("span");
    petal.className = "petal";
    petal.setAttribute("aria-hidden", "true");
    petal.textContent = petals[Math.floor(Math.random() * petals.length)];
    petal.style.left = `${Math.random() * 100}vw`;
    petal.style.fontSize = `${12 + Math.random() * 13}px`;
    petal.style.animationDuration = `${8 + Math.random() * 8}s`;
    document.body.appendChild(petal);
    window.setTimeout(() => petal.remove(), 17000);
  }
  window.setInterval(createPetal, 850);
})();
